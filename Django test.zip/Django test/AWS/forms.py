from django import forms
from  .models import djangodb

class inForm(forms.ModelForm):
  class Meta:
    model = djangodb
    fields = "__all__"