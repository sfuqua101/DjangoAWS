from django.db import models

# Create your models here.
class djangodb(models.Model):
  Name = models.TextField()
  Age = models.IntegerField()

class Test(models.Model):
  Name = models.TextField()
  Age = models.IntegerField()