"""
Render HTML web pages
"""
from django.http import HttpResponse
from django.template.loader import render_to_string
from django.shortcuts import render
from django.forms import formset_factory
from AWS.models import djangodb
from AWS.forms import inForm

HTML_str = """
<h1>Hello World</h1>
"""

#obj = djangodb(Name = "Ferrah", Age = 3)
#obj.save()

def home_view(request):
  """
  take in Django request and return HTML as response
  """
  context = {}
  informset = formset_factory(inForm)
  formset = informset(request.POST)
  if formset.is_valid():
    print("Success")
    for form in formset:
      form.save(commit = True)
  else:
    print("Failed")
  # HTML_str = render_to_string("home-view.html", context=context)
  context['formset']= formset
  return render(request, "home-view.html", context)
